"use client";

import { useState } from "react";
import { profile } from "@/lib/data";

export default function ContactForm() {
  const [name, setName] = useState("");
  const [message, setMessage] = useState("");

  const send = () => {
    const subject = encodeURIComponent(`Portfolio message from ${name || "a visitor"}`);
    const body = encodeURIComponent(message);
    window.location.href = `mailto:${profile.email}?subject=${subject}&body=${body}`;
  };

  const field = "w-full rounded-xl border border-white/20 bg-night px-4 py-3 text-wash placeholder:text-mute/70";

  return (
    <div className="space-y-4">
      <label className="block">
        <span className="mb-1 block text-mute">Your name</span>
        <input value={name} onChange={(e) => setName(e.target.value)} className={field} autoComplete="name" />
      </label>
      <label className="block">
        <span className="mb-1 block text-mute">Message</span>
        <textarea value={message} onChange={(e) => setMessage(e.target.value)} rows={5} className={field} />
      </label>
      <button type="button" onClick={send} className="display rounded-full bg-blue px-6 py-3 font-semibold text-white transition-colors hover:bg-sky hover:text-night">
        Send by email
      </button>
    </div>
  );
}
