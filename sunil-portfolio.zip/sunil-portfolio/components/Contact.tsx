import ContactForm from "./ContactForm";
import { profile } from "@/lib/data";

export default function Contact() {
  const l = profile.links;
  return (
    <section id="contact" className="mx-auto max-w-6xl px-5 py-24">
      <h2 className="text-4xl font-bold sm:text-5xl">Contact</h2>
      <div className="mt-10 grid gap-14 lg:grid-cols-2">
        <div>
          <p className="max-w-md text-mute">{profile.about}</p>
          <a href={`mailto:${profile.email}`} className="display mt-8 block break-all text-2xl font-semibold text-sky hover:text-gold sm:text-3xl">
            {profile.email}
          </a>
          <a href={profile.phoneHref} className="mt-2 block text-xl hover:text-gold">{profile.phone}</a>
          <ul className="mt-8 flex flex-wrap gap-x-6 gap-y-2">
            <li><a href={l.github} target="_blank" rel="noopener noreferrer" className="underline underline-offset-4 hover:text-gold">GitHub</a></li>
            <li><a href={l.linkedin} target="_blank" rel="noopener noreferrer" className="underline underline-offset-4 hover:text-gold">LinkedIn</a></li>
            <li><a href={l.instagram} target="_blank" rel="noopener noreferrer" className="underline underline-offset-4 hover:text-gold">Instagram</a></li>
            <li><a href={profile.resume} download className="underline underline-offset-4 hover:text-gold">Resume (PDF)</a></li>
          </ul>
        </div>
        <ContactForm />
      </div>
      <p className="mt-24 text-mute">© {new Date().getFullYear()} Sunil Soni</p>
    </section>
  );
}
