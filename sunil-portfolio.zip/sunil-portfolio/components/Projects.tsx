import Cover from "./Cover";
import { projects, type Project } from "@/lib/data";

function Tags({ items }: { items: string[] }) {
  return (
    <ul className="mt-5 flex flex-wrap gap-2 text-sm">
      {items.map((t) => (
        <li key={t} className="rounded-full border border-white/20 px-3 py-0.5 text-mute">{t}</li>
      ))}
    </ul>
  );
}

function Feature({ p, flip }: { p: Project; flip: boolean }) {
  return (
    <article className="grid items-center gap-8 lg:grid-cols-2 lg:gap-14">
      <div className={flip ? "lg:order-2" : ""}>
        <div className="relative aspect-[16/10] overflow-hidden rounded-2xl bg-panel">
          <Cover src={p.image} title={p.title} sizes="(min-width: 1024px) 560px, 100vw" />
        </div>
      </div>
      <div>
        <p className="text-sky">{p.kind}</p>
        <h3 className="mt-1 text-3xl font-semibold sm:text-4xl">{p.title}</h3>
        <p className="mt-4 text-mute">{p.summary}</p>
        <ul className="mt-4 space-y-2">
          {p.highlights.map((h) => (
            <li key={h} className="flex gap-3">
              <span aria-hidden className="mt-3 h-1.5 w-1.5 shrink-0 rounded-full bg-gold" />
              <span>{h}</span>
            </li>
          ))}
        </ul>
        <Tags items={p.stack} />
        {p.live ? (
          <a href={p.live} target="_blank" rel="noopener noreferrer" className="display mt-6 inline-block rounded-full bg-blue px-5 py-2.5 font-semibold text-white transition-colors hover:bg-sky hover:text-night">
            Open live site
          </a>
        ) : null}
      </div>
    </article>
  );
}

export default function Projects() {
  const featured = projects.filter((p) => p.featured);
  const more = projects.filter((p) => !p.featured);
  return (
    <section id="projects" className="mx-auto max-w-6xl px-5 py-24">
      <h2 className="text-4xl font-bold sm:text-5xl">Projects</h2>
      <p className="mt-3 max-w-xl text-mute">Full-stack builds first, then smaller experiments.</p>

      <div className="mt-14 space-y-24">
        {featured.map((p, i) => (
          <Feature key={p.slug} p={p} flip={i % 2 === 1} />
        ))}
      </div>

      <h3 className="mt-28 text-3xl font-semibold">More work</h3>
      <ul className="mt-8 divide-y divide-white/10 border-y border-white/10">
        {more.map((p) => (
          <li key={p.slug} className="grid items-center gap-5 py-6 sm:grid-cols-[9rem_1fr_auto]">
            <div className="relative aspect-[16/10] overflow-hidden rounded-xl bg-panel">
              <Cover src={p.image} title={p.title} sizes="144px" />
            </div>
            <div>
              <h4 className="display text-xl font-semibold">{p.title}</h4>
              <p className="mt-1 text-mute">{p.summary}</p>
            </div>
            {p.live ? (
              <a href={p.live} target="_blank" rel="noopener noreferrer" className="text-sky underline underline-offset-4 hover:text-gold">
                Open {p.slug === "simon-game" ? "game" : "demo"}
              </a>
            ) : (
              <span className="text-mute">On the Play Store</span>
            )}
          </li>
        ))}
      </ul>
    </section>
  );
}
