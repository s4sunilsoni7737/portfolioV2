"use client";

import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import Image from "next/image";
import Cover from "./Cover";
import { profile, projects } from "@/lib/data";

gsap.registerPlugin(ScrollTrigger);

const proj = (slug: string) => projects.find((p) => p.slug === slug)!;

type Panel = { title: string; src?: string; photo?: boolean };
const panels: Panel[] = [
  { title: "Sunil Soni", src: "/images/sunil-mirror.jpg", photo: true },
  { title: proj("course-platform").title, src: proj("course-platform").image },
  { title: proj("jewellery-showcase").title, src: proj("jewellery-showcase").image },
  { title: proj("hotel-management").title },
  { title: "Sunil Soni", src: "/images/sunil-hills.jpg", photo: true },
  { title: proj("airbnb-clone").title, src: proj("airbnb-clone").image },
  { title: proj("spotify-clone").title, src: proj("spotify-clone").image },
  { title: proj("simon-game").title, src: proj("simon-game").image },
];

export default function Hero() {
  const sectionRef = useRef<HTMLElement>(null);
  const stageRef = useRef<HTMLDivElement>(null);
  const tiltRef = useRef<HTMLDivElement>(null);
  const ringRef = useRef<HTMLDivElement>(null);
  const stateRef = useRef({ auto: 0, drag: 0, scroll: 0, intro: 0, scale: 1, vel: 0 });

  useEffect(() => {
    const section = sectionRef.current;
    const stage = stageRef.current;
    const ring = ringRef.current;
    const tilt = tiltRef.current;
    if (!section || !stage || !ring || !tilt) return;

    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const s = stateRef.current;
    s.intro = reduce ? 0 : -160;
    s.scale = reduce ? 1 : 0.7;

    let dragging = false;
    let lastX = 0;

    const apply = () =>
      gsap.set(ring, { rotationY: s.auto + s.drag + s.scroll + s.intro, scale: s.scale });

    const tick = (_time: number, dt: number) => {
      if (!reduce && !dragging) s.auto += dt * 0.006;
      if (!dragging && Math.abs(s.vel) > 0.01) {
        s.drag += s.vel;
        s.vel *= 0.95;
      }
      apply();
    };
    gsap.ticker.add(tick);

    const down = (e: PointerEvent) => {
      dragging = true;
      lastX = e.clientX;
      s.vel = 0;
      stage.setPointerCapture(e.pointerId);
    };
    const move = (e: PointerEvent) => {
      if (!dragging) return;
      const dx = (e.clientX - lastX) * 0.35;
      lastX = e.clientX;
      s.drag += dx;
      s.vel = dx;
    };
    const up = () => { dragging = false; };
    stage.addEventListener("pointerdown", down);
    stage.addEventListener("pointermove", move);
    stage.addEventListener("pointerup", up);
    stage.addEventListener("pointercancel", up);

    const trigger = ScrollTrigger.create({
      trigger: section,
      start: "top top",
      end: "bottom top",
      scrub: true,
      onUpdate: (self) => { s.scroll = self.progress * 180; },
    });

    const tweens: gsap.core.Tween[] = [];
    if (!reduce) {
      tweens.push(gsap.to(s, { intro: 0, scale: 1, duration: 2.2, ease: "power3.out" }));
      tweens.push(gsap.from(tilt, { opacity: 0, duration: 1.2, ease: "power2.out" }));
    }

    return () => {
      gsap.ticker.remove(tick);
      trigger.kill();
      tweens.forEach((t) => t.kill());
      stage.removeEventListener("pointerdown", down);
      stage.removeEventListener("pointermove", move);
      stage.removeEventListener("pointerup", up);
      stage.removeEventListener("pointercancel", up);
    };
  }, []);

  const nudge = (deg: number) => {
    gsap.to(stateRef.current, { drag: `+=${deg}`, duration: 0.9, ease: "power3.out" });
  };

  return (
    <section ref={sectionRef} id="top" className="relative overflow-hidden pt-24 pb-10 lg:pt-28">
      <div className="mx-auto grid max-w-6xl items-center gap-6 px-5 lg:grid-cols-[0.9fr_1.1fr]">
        <div className="relative z-10">
          <h1 className="text-6xl font-bold sm:text-7xl lg:text-8xl">Sunil Soni</h1>
          <p className="mt-4 text-2xl font-medium text-sky display">
            {profile.role} from {profile.city.split(",")[0]}
          </p>
          <p className="mt-5 max-w-md text-mute">{profile.intro}</p>
          <div className="mt-8 flex flex-wrap gap-3">
            <a href="#projects" className="rounded-full bg-blue px-6 py-3 font-semibold text-white transition-colors hover:bg-sky hover:text-night display">
              View projects
            </a>
            <a href={profile.resume} download className="rounded-full border border-white/25 px-6 py-3 font-semibold transition-colors hover:border-gold hover:text-gold display">
              Download resume
            </a>
          </div>
        </div>

        <div className="relative">
          <div aria-hidden className="absolute left-1/2 top-1/2 h-[18rem] w-[18rem] -translate-x-1/2 -translate-y-1/2 rounded-full bg-blue sm:h-[24rem] sm:w-[24rem] lg:h-[28rem] lg:w-[28rem]" />
          <div ref={stageRef} className="ring-stage relative flex h-[22rem] items-center md:h-[28rem] lg:h-[32rem]" aria-label="Rotating gallery of Sunil and his projects. Drag to rotate.">
            <div ref={tiltRef} className="ring-tilt w-full">
              <div ref={ringRef} className="ring">
                {panels.map((p, i) => (
                  <div key={i} className="ring-panel" style={{ ["--i" as string]: i }}>
                    {p.photo && p.src ? (
                      <Image src={p.src} alt="Portrait of Sunil Soni" fill sizes="240px" priority={i === 0} className="object-cover" draggable={false} />
                    ) : (
                      <Cover src={p.src} title={p.title} sizes="240px" />
                    )}
                    {!p.photo && (
                      <span className="absolute inset-x-0 bottom-0 bg-night/80 px-3 py-2 text-sm display">{p.title}</span>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
          <div className="relative z-10 mt-2 flex items-center justify-center gap-4 text-sm text-mute">
            <button type="button" onClick={() => nudge(45)} aria-label="Rotate gallery left" className="h-10 w-10 rounded-full border border-white/25 hover:border-gold hover:text-gold">‹</button>
            <span>Drag to rotate</span>
            <button type="button" onClick={() => nudge(-45)} aria-label="Rotate gallery right" className="h-10 w-10 rounded-full border border-white/25 hover:border-gold hover:text-gold">›</button>
          </div>
        </div>
      </div>
    </section>
  );
}
