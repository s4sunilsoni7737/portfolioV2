"use client";

import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { experience } from "@/lib/data";

gsap.registerPlugin(ScrollTrigger);

export default function Experience() {
  const listRef = useRef<HTMLOListElement>(null);
  const lineRef = useRef<HTMLSpanElement>(null);

  useEffect(() => {
    const list = listRef.current;
    const line = lineRef.current;
    if (!list || !line) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const tween = gsap.fromTo(
      line,
      { scaleY: 0 },
      { scaleY: 1, ease: "none", scrollTrigger: { trigger: list, start: "top 70%", end: "bottom 70%", scrub: true } },
    );
    return () => {
      tween.scrollTrigger?.kill();
      tween.kill();
    };
  }, []);

  return (
    <section id="experience" className="mx-auto max-w-6xl px-5 py-24">
      <h2 className="text-4xl font-bold sm:text-5xl">Experience</h2>
      <ol ref={listRef} className="relative mt-12 max-w-3xl space-y-12 pl-8">
        <span aria-hidden className="absolute left-[5px] top-2 bottom-2 w-px bg-white/15" />
        <span ref={lineRef} aria-hidden className="absolute left-[5px] top-2 bottom-2 w-px origin-top bg-gold" />
        {experience.map((e) => (
          <li key={e.role + e.when} className="relative">
            <span aria-hidden className="absolute -left-8 top-2.5 h-[11px] w-[11px] rounded-full bg-gold" />
            <p className="text-sky">{e.when}</p>
            <h3 className="mt-1 text-2xl font-semibold">{e.role}</h3>
            <p className="text-mute">{e.org}</p>
            <ul className="mt-3 list-disc space-y-1 pl-5 marker:text-gold">
              {e.points.map((pt) => <li key={pt}>{pt}</li>)}
            </ul>
          </li>
        ))}
      </ol>
    </section>
  );
}
