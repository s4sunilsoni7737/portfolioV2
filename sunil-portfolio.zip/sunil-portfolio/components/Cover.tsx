import Image from "next/image";

type Props = {
  src?: string;
  title: string;
  sizes: string;
  priority?: boolean;
};

export default function Cover({ src, title, sizes, priority }: Props) {
  if (!src) {
    return (
      <div className="absolute inset-0 flex items-end bg-panel p-5">
        <span className="display text-2xl font-semibold text-wash">{title}</span>
      </div>
    );
  }
  return (
    <Image src={src} alt={`${title} screenshot`} fill sizes={sizes} priority={priority} className="object-cover" />
  );
}
