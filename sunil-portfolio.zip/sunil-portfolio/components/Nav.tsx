const links = [
  { href: "#projects", label: "Projects" },
  { href: "#experience", label: "Experience" },
  { href: "#skills", label: "Skills" },
  { href: "#contact", label: "Contact" },
];

export default function Nav() {
  return (
    <header className="fixed inset-x-0 top-0 z-50 border-b border-white/10 bg-night/85 backdrop-blur">
      <nav className="mx-auto flex max-w-6xl items-center justify-between px-5 py-3.5" aria-label="Main">
        <a href="#top" className="display text-lg font-semibold">Sunil Soni</a>
        <ul className="flex gap-4 text-sm sm:gap-7 sm:text-base">
          {links.map((l) => (
            <li key={l.href}>
              <a href={l.href} className="text-mute transition-colors hover:text-wash">{l.label}</a>
            </li>
          ))}
        </ul>
      </nav>
    </header>
  );
}
