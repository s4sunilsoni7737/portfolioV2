import { skills, education, certifications } from "@/lib/data";

export default function Skills() {
  return (
    <section id="skills" className="bg-panel">
      <div className="mx-auto max-w-6xl px-5 py-24">
        <h2 className="text-4xl font-bold sm:text-5xl">Skills</h2>
        <div className="mt-10 grid gap-10 sm:grid-cols-2 lg:grid-cols-4">
          {skills.map((g) => (
            <div key={g.group}>
              <h3 className="text-xl font-semibold text-gold">{g.group}</h3>
              <ul className="mt-3 space-y-1.5">
                {g.items.map((i) => <li key={i}>{i}</li>)}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-24 grid gap-14 lg:grid-cols-2">
          <div>
            <h2 className="text-3xl font-bold">Education</h2>
            <ul className="mt-6 space-y-6">
              {education.map((e) => (
                <li key={e.title}>
                  <h3 className="display text-xl font-semibold">{e.title}</h3>
                  <p className="text-mute">{e.place}</p>
                  <p className="text-sky">{e.when}, {e.score}</p>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h2 className="text-3xl font-bold">Certifications</h2>
            <ul className="mt-6 list-disc space-y-3 pl-5 marker:text-gold">
              {certifications.map((c) => <li key={c}>{c}</li>)}
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}
