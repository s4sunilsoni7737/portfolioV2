export type Project = {
  slug: string;
  title: string;
  kind: string;
  summary: string;
  highlights: string[];
  stack: string[];
  image?: string;
  live?: string;
  liveLabel?: string;
  featured: boolean;
};

const OLD = "https://s4sunilsoni7737.github.io/portfolio";

export const profile = {
  name: "Sunil Soni",
  role: "Full-stack developer",
  city: "Jodhpur, Rajasthan",
  email: "s4sunilsoni7737@gmail.com",
  phone: "8000597887",
  phoneHref: "tel:+918000597887",
  resume: "/Sunil_Soni_Resume.pdf",
  links: {
    github: "https://github.com/s4sunilsoni7737",
    linkedin: "https://www.linkedin.com/in/sunil-soni-a99aa324b/",
    instagram: "https://www.instagram.com/sunil_soni7737/",
    oldPortfolio: `${OLD}/`,
  },
  intro:
    "I build REST APIs, admin panels and storefronts with NestJS, Next.js and MongoDB. I work at MTOS Company in Jodhpur, and I ship backend features that frontend and QA teams can rely on.",
  about:
    "I finished my B.Tech in Computer Science in 2026. Before that I trained and interned across Jodhpur and Jaipur, moving from MERN projects to backend systems with authentication, role-based access control and payment webhooks. I like clean, modular code and debugging until the cause is clear.",
};

export const projects: Project[] = [
  {
    slug: "course-platform",
    title: "Advanced Course Selling Platform",
    kind: "MERN Stack · E-Learning",
    summary:
      "A full course-selling platform with separate instructor and student dashboards. Instructors upload video lessons and track earnings; students enrol, learn and track progress.",
    highlights: [
      "Course access, downloads and progress tracking",
      "Instructor earnings with analytics and withdrawal history",
      "Razorpay and Stripe payments with webhook verification",
      "Admin panel for users, instructors, categories and payments",
    ],
    stack: ["MongoDB", "Express", "React", "Node.js", "Razorpay", "Stripe"],
    image: `${OLD}/course-website.PNG`,
    live: "https://course-website-yec8.onrender.com/",
    featured: true,
  },
  {
    slug: "jewellery-showcase",
    title: "Jewellery Showcase Website",
    kind: "Web Design · E-Commerce",
    summary:
      "A catalogue site for a jewellery business, with category filtering, image uploads through Cloudinary and prices that follow live metal rates.",
    highlights: [
      "1000+ product catalogue with category-based filtering",
      "Real-time metal rates with automatic price updates",
      "Multilingual interface",
      "Admin panel for products and categories",
    ],
    stack: ["MongoDB", "Express", "React", "Node.js", "Cloudinary"],
    image: `${OLD}/jewellery1.png`,
    live: "https://jewelry-website-8x78.onrender.com/products",
    featured: true,
  },
  {
    slug: "airbnb-clone",
    title: "Airbnb Clone",
    kind: "Web Platform · Marketplace",
    summary:
      "A property marketplace where people register, list places to stay, upload photos and post reviews. Hosts manage listings from their own dashboard.",
    highlights: [
      "Host dashboards for listing and managing properties",
      "Secure authentication and a booking system",
      "Payment gateway and advanced search filters",
      "Image upload and reviews",
    ],
    stack: ["Node.js", "Express", "MongoDB", "Bootstrap"],
    image: `${OLD}/airbnb.jpg`,
    live: "https://airbnb-clone-06vq.onrender.com/listings",
    featured: true,
  },
  {
    slug: "hotel-management",
    title: "Hotel Management System",
    kind: "MERN Stack · Operations",
    summary:
      "A room booking and customer management system for hotel staff, with an admin dashboard that covers revenue, rooms and daily check-ins.",
    highlights: [
      "Room booking and customer management",
      "Dashboard for revenue, rooms, check-in and check-out",
      "Automated invoices",
      "Real-time room availability updates",
    ],
    stack: ["MongoDB", "Express", "React", "Node.js"],
    featured: true,
  },
  {
    slug: "spotify-clone",
    title: "Spotify Web Player",
    kind: "Front end only",
    summary:
      "A front-end clone of the Spotify web player, built to practise layout and design. Music playback is planned for a later version.",
    highlights: [],
    stack: ["HTML", "CSS", "JavaScript"],
    image: `${OLD}/spotify.jpg`,
    live: `${OLD}/spotifyClone.html`,
    featured: false,
  },
  {
    slug: "simon-game",
    title: "Simon Game",
    kind: "Browser game",
    summary:
      "The game shows a sequence of coloured buttons and you repeat it. The sequence grows longer after every round.",
    highlights: [],
    stack: ["HTML", "CSS", "JavaScript"],
    image: `${OLD}/simon.jpg`,
    live: `${OLD}/simongame.html`,
    featured: false,
  },
  {
    slug: "shopping-app",
    title: "Online Shopping App",
    kind: "Mobile app",
    summary:
      "A mobile app that connects shoppers with talented people around the world. It is listed on the Play Store.",
    highlights: [],
    stack: ["Mobile"],
    featured: false,
  },
];

export const experience = [
  {
    role: "Full-stack Developer",
    org: "MTOS Company, Jodhpur",
    when: "Dec 2025 – Present",
    points: [
      "Build with NestJS, TypeScript, Node.js, Next.js and MongoDB.",
      "Develop REST APIs with validation, authentication and role-based access control.",
      "Keep the backend modular with DTOs and service-based design.",
      "Work with frontend and QA teams to release stable, production-ready features.",
    ],
  },
  {
    role: "Backend Development Intern",
    org: "Renx Labs Private Limited, Jodhpur",
    when: "May 2025 – Aug 2025",
    points: [
      "Built backend systems with Node.js, Express.js and MongoDB.",
      "Built and optimised REST APIs for efficient data operations.",
    ],
  },
  {
    role: "MERN Stack Trainee & Intern",
    org: "Zeetron Network Pvt Ltd, Jaipur",
    when: "Jun 2024 – Jul 2024",
    points: ["Completed real-world MERN projects with hands-on training."],
  },
  {
    role: "Full Stack Development Trainee",
    org: "WsCube Tech, Jodhpur",
    when: "May 2023 – Jul 2024",
    points: [
      "Built REST APIs with FastAPI and MongoDB.",
      "Developed MERN stack and PostgreSQL-based applications.",
    ],
  },
];

export const skills = [
  { group: "Frontend", items: ["Next.js", "React", "TypeScript", "JavaScript", "HTML", "CSS", "Tailwind CSS", "Bootstrap"] },
  { group: "Backend", items: ["NestJS", "Node.js", "Express.js", "REST APIs", "Authentication & RBAC"] },
  { group: "Data", items: ["MongoDB", "PostgreSQL", "MySQL"] },
  { group: "Tools", items: ["Git", "GitHub", "VS Code", "Razorpay", "Stripe"] },
];

export const education = [
  { title: "B.Tech, Computer Science", place: "Jodhpur Institute of Engineering and Technology, Rajasthan", when: "Aug 2022 – May 2026", score: "CGPA 7.28" },
  { title: "12th (Science)", place: "Anant Lewis Public Sr Sec School, Jodhpur", when: "2021 – 2022", score: "82.4%" },
  { title: "10th", place: "Diamond Academy Sr Sec School, Jodhpur", when: "2020", score: "65%" },
];

export const certifications = [
  "MERN Stack Internship — Zeetron Network Pvt Ltd, Jaipur",
  "Software Testing Techniques — Infosys Springboard",
  "Full Stack Development Training — WsCube Tech, Jodhpur",
  "Ethics in Engineering Practice — NPTEL",
];
